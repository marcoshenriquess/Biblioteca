const express = require('express');
const UserController = require('../controller/usuarioController');

class UserRouter{
    #router;
    get router(){
        return this.#router;
    }

    set router(router){
        this.#router = router;
    }

    constructor(){
        this.#router = express.Router();
        let ctrl = new UserController();
        this.#router.get('/login',ctrl.UserCadastro);
    }
}
module.exports = UserRouter;