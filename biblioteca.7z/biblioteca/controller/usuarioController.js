class UserController{
    constructor(){

    }
    UserCadastro(req,res){
        res.render('usuario/cadastrar', { });
    }
}
module.exports = UserController;